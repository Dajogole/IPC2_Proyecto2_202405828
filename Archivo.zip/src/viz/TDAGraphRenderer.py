from graphviz import Digraph
import os

class TDAGraphRenderer:
    def __init__(self, out_dir: str):
        self.out_dir = out_dir

    def render_estado(self, invernadero, resultado_plan, t: int):
        """
        Dibuja un grafo simple del estado en tiempo t:
        - Subgrafo por cada hilera con nodos P0..Pn (0 es inicio)
        - Dron como nodo con etiqueta (DRxx @ Pk : accion)
        """
        dot = Digraph(comment="Estado TDA t={}".format(t))
        dot.attr(rankdir="LR")
        # Por cada hilera, dibujar P0..P{N}
        for par_h in invernadero.hileras:
            hilera = par_h.v
            with dot.subgraph(name="cluster_h{}".format(hilera.numero)) as c:
                c.attr(label="Hilera H{}".format(hilera.numero))
                # P0..P{plantas_x_hilera}
                # P0
                c.node("H{}P0".format(hilera.numero), "H{}:P0".format(hilera.numero), shape="circle")
                # del 1 al plantas_x_hilera
                i = 1
                while i <= invernadero.plantas_x_hilera:
                    c.node("H{}P{}".format(hilera.numero, i), "H{}:P{}".format(hilera.numero, i), shape="circle")
                    # enlace lineal
                    prev = "H{}P{}".format(hilera.numero, i-1)
                    curr = "H{}P{}".format(hilera.numero, i)
                    c.edge(prev, curr, dir="both")
                    i += 1

        # Encontrar acciones en tiempo t
        tiempo = None
        for it in resultado_plan.timeline:
            if int(it.segundos) == int(t):
                tiempo = it
                break

        # Dron nodes con posición aproximada según su acción en t (heurística: parsear último P# de la acción)
        for par_asig in invernadero.asignaciones:
            dr = par_asig.v
            label = dr.nombre + " @ ?"
            accion = "Esperar"
            pos = "0"
            if tiempo is not None:
                for acc in tiempo.acciones:
                    if acc.dron_nombre == dr.nombre:
                        accion = acc.accion
                        # extraer P#
                        p = self._parse_posicion(accion)
                        if p is not None:
                            pos = str(p)
                        break
            label = "{} @ P{} : {}".format(dr.nombre, pos, accion)
            node_id = "DR_" + dr.nombre
            dot.node(node_id, label, shape="box")
            # Conectar al nodo de la hilera y posición
            dot.edge(node_id, "H{}P{}".format(dr.hilera, pos), style="dashed")

        out_path = os.path.join(self.out_dir, "tda_t{}.gv".format(int(t)))
        dot.render(out_path, format="svg", cleanup=True)
        return out_path + ".svg"

    def _parse_posicion(self, accion: str):
        # busca "P<number>" en la cadena
        if accion is None:
            return None
        i = 0
        n = len(accion)
        while i < n:
            if accion[i] == 'P':
                i += 1
                num = 0
                found = False
                while i < n and accion[i].isdigit():
                    num = num * 10 + (ord(accion[i]) - 48)
                    i += 1
                    found = True
                if found:
                    return num
            else:
                i += 1
        return None
