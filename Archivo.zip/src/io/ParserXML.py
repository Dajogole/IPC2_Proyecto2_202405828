# Parser por streaming (iterparse) para evitar usar listas nativas.
import xml.etree.ElementTree as ET
from ..tda.Mapa import Mapa
from ..tda.ListaSimple import ListaSimple
from ..domain import Planta, Dron, Hilera, Invernadero, PlanRiego, PasoPlan
from ..core.Sistema import Sistema

class ParserXML:
    def __init__(self, sistema: Sistema):
        self.sistema = sistema

    def cargar_desde_archivo(self, ruta_xml: str):
        # Limpiar estado actual
        self.sistema.reset()

        # Estructuras temporales para la configuración
        # drones_global: Mapa id(int)->Dron
        drones_global = Mapa()
        # invernaderos: ListaSimple de Invernadero
        invernaderos_lista = ListaSimple()

        # Variables auxiliares para el invernadero actual
        inv_nombre = None
        inv_num_h = None
        inv_px_h = None
        inv_hileras = None
        inv_asignaciones = None
        inv_planes = None
        inv_plants_mapa = None  # mapa temporal por hilera: hilera_num -> Mapa pos->Planta

        current_invernadero = None

        for event, elem in ET.iterparse(ruta_xml, events=("start", "end")):
            tag = elem.tag.strip()

            if event == "start":
                if tag == "invernadero":
                    inv_nombre = elem.attrib.get("nombre")
                    inv_hileras = Mapa()
                    inv_asignaciones = Mapa()
                    inv_planes = ListaSimple()
                    inv_plants_mapa = Mapa()
                # nothing else on start needed
            else:
                # event == "end"
                if tag == "dron" and elem.attrib.get("nombre") is not None:
                    # es un dron de listaDrones
                    id_str = elem.attrib.get("id")
                    nombre = elem.attrib.get("nombre")
                    try:
                        idnum = int(id_str)
                    except:
                        idnum = id_str
                    drones_global.set(idnum, Dron(idnum, nombre))

                elif tag == "numeroHileras":
                    inv_num_h = int(elem.text.strip()) if elem.text else 0

                elif tag == "plantasXhilera":
                    inv_px_h = int(elem.text.strip()) if elem.text else 0

                elif tag == "planta":
                    # planta dentro de listaPlantas (del invernadero actual)
                    hilera = int(elem.attrib.get("hilera"))
                    posicion = int(elem.attrib.get("posicion"))
                    litros = float(elem.attrib.get("litrosAgua"))
                    gramos = float(elem.attrib.get("gramosFertilizante"))
                    nombre_planta = (elem.text or "").strip()

                    planta = Planta(hilera, posicion, litros, gramos, nombre_planta)
                    # Guardar en un mapa por hilera
                    mapa_pl_hilera = inv_plants_mapa.get(hilera)
                    if mapa_pl_hilera is None:
                        from ..tda.Mapa import Mapa as _Mapa
                        mapa_pl_hilera = _Mapa()
                        inv_plants_mapa.set(hilera, mapa_pl_hilera)
                    mapa_pl_hilera.set(posicion, planta

                    )

                elif tag == "dron" and elem.attrib.get("hilera") is not None:
                    # asignación dron-hilera
                    id_str = elem.attrib.get("id")
                    hilera = int(elem.attrib.get("hilera"))
                    try:
                        idnum = int(id_str)
                    except:
                        idnum = id_str
                    dr = drones_global.get(idnum)
                    if dr is not None:
                        # aún no seteamos la hilera, lo haremos al cerrar invernadero para crear clones por inv.
                        inv_asignaciones.set(hilera, dr)

                elif tag == "plan":
                    nombre_plan = elem.attrib.get("nombre")
                    texto = (elem.text or "").strip()
                    # Formato exacto: H#-P# separados por comas
                    pasos = ListaSimple()
                    # Separamos manualmente sin listas: recorrer carácter por carácter y acumular tokens
                    # (pero una división básica por coma generaría lista; evitamos .split(','))
                    # Implementamos un pequeño escáner:
                    token = ""
                    i = 0
                    n = len(texto)
                    while i < n:
                        c = texto[i]
                        if c == ",":
                            s = token.strip()
                            if s:
                                self._agregar_paso_desde_str(pasos, s)
                            token = ""
                        else:
                            token += c
                        i += 1
                    s = token.strip()
                    if s:
                        self._agregar_paso_desde_str(pasos, s)

                    inv_planes.append(PlanRiego(nombre_plan, pasos))

                elif tag == "invernadero":
                    # Construir hileras (cada hilera contiene mapa de plantas)
                    from ..tda.Mapa import Mapa as _Mapa
                    hileras_mapa = _Mapa()
                    # Crear Hilera para cada número existente en inv_plants_mapa
                    for par in inv_plants_mapa:
                        hileras_mapa.set(par.k, Hilera(par.k, par.v))

                    # Clonar drones para asignaciones de este invernadero, con hilera asignada
                    asignaciones_mapa = _Mapa()
                    for par in inv_asignaciones:
                        original = par.v
                        clon = Dron(original.id, original.nombre)
                        clon.hilera = par.k
                        asignaciones_mapa.set(par.k, clon)

                    inv = Invernadero(inv_nombre, inv_num_h, inv_px_h, hileras_mapa, asignaciones_mapa, inv_planes)
                    invernaderos_lista.append(inv)

                    # Limpiar variables del invernadero actual
                    inv_nombre = None
                    inv_num_h = None
                    inv_px_h = None
                    inv_hileras = None
                    inv_asignaciones = None
                    inv_planes = None
                    inv_plants_mapa = None

        # Actualizar sistema
        self.sistema.drones_global = drones_global
        self.sistema.invernaderos = invernaderos_lista

    def _agregar_paso_desde_str(self, pasos_lista, s):
        # s: "H#-P#"
        # Buscar H, -, P de forma manual
        # Ejemplo "H3-P10"
        i = 0
        n = len(s)
        # Leer 'H'
        while i < n and s[i] == ' ':
            i += 1
        if i < n and (s[i] == 'H' or s[i] == 'h'):
            i += 1
        # Leer número de hilera
        num_h = 0
        while i < n and s[i].isdigit():
            num_h = num_h * 10 + (ord(s[i]) - 48)
            i += 1
        # saltar espacios
        while i < n and s[i] in ' -':
            if s[i] == '-':
                i += 1
                break
            i += 1
        # Esperar 'P'
        while i < n and s[i] == ' ':
            i += 1
        if i < n and (s[i] == 'P' or s[i] == 'p'):
            i += 1
        num_p = 0
        while i < n and s[i].isdigit():
            num_p = num_p * 10 + (ord(s[i]) - 48)
            i += 1
        pasos_lista.append(PasoPlan(num_h, num_p))
