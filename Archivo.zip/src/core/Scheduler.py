from ..tda.ListaSimple import ListaSimple
from ..tda.Mapa import Mapa, Par
from ..domain import InstruccionDron, InstruccionesTiempo, PasoPlan, ParNumeros, ResultadoPlan

class Scheduler:
    """
    Simulación segundo a segundo con reglas:
      - Mover 1 posición = 1s
      - Regar = 1s
      - Sólo 1 dron puede regar por segundo (el del siguiente paso del plan)
      - Los demás pueden moverse 1 posición hacia su siguiente objetivo o esperar
    """
    def __init__(self, invernadero, drones_mapa):
        self.inv = invernadero                          # Invernadero
        self.drones = drones_mapa                       # Mapa dron_nombre -> Dron (clon)
        self._agua_total = 0.0
        self._fert_total = 0.0
        self._por_dron = Mapa()                         # dron_nombre -> ParNumeros
        self._timeline = ListaSimple()                  # ListaSimple[InstruccionesTiempo]

    # ----------------------- utilidades -----------------------
    def _buscar_plan(self, plan_nombre: str):
        if self.inv is None or self.inv.planes is None:
            return None
        for p in self.inv.planes:
            if p.nombre == plan_nombre:
                return p
        return None

    def _dron_por_hilera(self, hilera_num: int):
        # Asignación del invernadero: hilera -> Dron (plantilla)
        asign = self.inv.asignaciones.get(hilera_num)
        if asign is None:
            return None
        # Buscar el clon en self.drones por nombre
        dron = self.drones.get(asign.nombre)
        if dron is not None:
            return dron
        # fallback por id (por si el Mapa fue indexado distinto)
        dron = self.drones.get(getattr(asign, "id", None))
        return dron

    def _planta(self, h: int, p: int):
        hil = self.inv.hileras.get(h)
        if hil is None:
            return None
        if hasattr(hil, "plantas"):
            return hil.plantas.get(p)
        return None

    def _len_lista(self, lista):
        try:
            return len(lista)
        except TypeError:
            c = 0
            for _ in lista:
                c += 1
            return c

    def _validar_plan(self, plan):
        n = self._len_lista(plan.pasos)
        if n == 0:
            raise ValueError("El plan no contiene pasos.")
        i = 0
        for paso in plan.pasos:
            if paso.hilera < 1 or paso.hilera > self.inv.numero_hileras:
                raise ValueError(f"Paso #{i+1}: hilera {paso.hilera} fuera de 1..{self.inv.numero_hileras}.")
            if paso.posicion < 1 or paso.posicion > self.inv.plantas_x_hilera:
                raise ValueError(f"Paso #{i+1}: posición {paso.posicion} fuera de 1..{self.inv.plantas_x_hilera}.")
            if self._dron_por_hilera(paso.hilera) is None:
                raise ValueError(f"Paso #{i+1}: la hilera {paso.hilera} no tiene dron asignado.")
            if self._planta(paso.hilera, paso.posicion) is None:
                raise ValueError(f"Paso #{i+1}: no existe la planta H{paso.hilera}-P{paso.posicion}.")
            i += 1

    def _init_por_dron(self):
        for par in self.drones:
            self._por_dron.set(par.k, ParNumeros(0.0, 0.0))

    def _siguiente_objetivo_para_hilera(self, plan, idx_actual, hilera):
        """Devuelve la PRÓXIMA posición a regar para esa hilera desde idx_actual (inclusive)."""
        i = idx_actual
        while True:
            try:
                paso = plan.pasos.obtener(i)
            except Exception:
                # fallback: iterar manualmente si tu ListaSimple no tiene "obtener"
                j = 0
                paso = None
                for pp in plan.pasos:
                    if j == i:
                        paso = pp
                        break
                    j += 1
            if paso is None:
                return None
            if paso.hilera == hilera:
                return paso.posicion
            i += 1

    # ----------------------- simulación -----------------------
    def ejecutar(self, plan_nombre: str):
        plan = self._buscar_plan(plan_nombre)
        if plan is None:
            raise ValueError("Plan no encontrado en el invernadero seleccionado.")

        self._validar_plan(plan)
        self._init_por_dron()

        total_pasos = self._len_lista(plan.pasos)
        # Cota de seguridad para evitar loops infinitos
        watchdog_max = total_pasos * (self.inv.plantas_x_hilera + 2) + 100

        idx = 0
        tiempo = 0

        while idx < total_pasos:
            tiempo += 1
            if tiempo > watchdog_max:
                raise RuntimeError("La simulación excedió el límite de seguridad. "
                                   "Revise asignaciones y pasos del plan (posiciones alcanzables).")

            acciones_seg = ListaSimple()

            # Paso objetivo (único que puede REGAR este segundo)
            try:
                paso = plan.pasos.obtener(idx)
            except Exception:
                j = 0
                paso = None
                for pp in plan.pasos:
                    if j == idx:
                        paso = pp
                        break
                    j += 1
            if paso is None:
                break

            hilera_obj = paso.hilera
            pos_obj    = paso.posicion

            # Dron que riega (si está en posición)
            dron_riego = self._dron_por_hilera(hilera_obj)
            if dron_riego is None:
                raise RuntimeError(f"No hay dron asignado para la hilera {hilera_obj}.")

            if dron_riego.posicion < pos_obj:
                dron_riego.posicion += 1
                acciones_seg.append(InstruccionDron(dron_riego.nombre, "Adelante"))
            elif dron_riego.posicion > pos_obj:
                dron_riego.posicion -= 1
                acciones_seg.append(InstruccionDron(dron_riego.nombre, "Atras"))
            else:
                acciones_seg.append(InstruccionDron(dron_riego.nombre, "Regar"))
                self._aplicar_riego(dron_riego, paso)
                idx += 1  # ¡avanza el plan!

            # El resto de drones
            for par in self.drones:
                dr = par.v
                if dr is dron_riego:
                    continue
                if getattr(dr, "terminado", False):
                    acciones_seg.append(InstruccionDron(dr.nombre, "FIN"))
                    continue

                objetivo = self._siguiente_objetivo_para_hilera(plan, idx, dr.hilera)
                if objetivo is None:
                    dr.terminado = True
                    acciones_seg.append(InstruccionDron(dr.nombre, "FIN"))
                    continue

                if dr.posicion < objetivo:
                    dr.posicion += 1
                    acciones_seg.append(InstruccionDron(dr.nombre, "Adelante"))
                elif dr.posicion > objetivo:
                    dr.posicion -= 1
                    acciones_seg.append(InstruccionDron(dr.nombre, "Atras"))
                else:
                    acciones_seg.append(InstruccionDron(dr.nombre, "Esperar"))

            # Registrar tick
            tick = InstruccionesTiempo(tiempo, acciones_seg)
            self._timeline.append(tick)

        return ResultadoPlan(
            tiempo_optimo=tiempo,
            agua_total=self._agua_total,
            fert_total=self._fert_total,
            por_dron_mapa=self._por_dron,
            timeline_lista=self._timeline
        )

    def _aplicar_riego(self, dron, paso):
        planta = self._planta(paso.hilera, paso.posicion)
        if planta is None:
            return
        dron.agua_acum = getattr(dron, "agua_acum", 0.0) + planta.litros
        dron.fert_acum = getattr(dron, "fert_acum", 0.0) + planta.gramos
        self._agua_total += planta.litros
        self._fert_total += planta.gramos

        par = self._por_dron.get(dron.nombre)
        if par is None:
            self._por_dron.set(dron.nombre, ParNumeros(planta.litros, planta.gramos))
        else:
            par.a += planta.litros
            par.b += planta.gramos
