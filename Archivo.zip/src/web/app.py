import os
from flask import Flask, render_template, request, redirect, url_for, send_from_directory, flash
from ..core.Sistema import Sistema
from ..io.ParserXML import ParserXML
from ..core.Simulador import Simulador
from ..io.WriterXML import WriterXML
from ..reports.ReporteHTML import ReporteHTML
from ..viz.TDAGraphRenderer import TDAGraphRenderer
from ..tda.ListaSimple import ListaSimple

# Inicializar sistema global
sistema = Sistema()

app = Flask(__name__, template_folder="templates", static_folder="static")
app.secret_key = "ipc2_p2_mac_safari"

app.config.update(
    SEND_FILE_MAX_AGE_DEFAULT=0,
    TEMPLATES_AUTO_RELOAD=True
)

@app.after_request
def no_cache(resp):
    resp.headers["Cache-Control"] = "no-store, max-age=0"
    return resp

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
DATA_DIR = os.path.join(BASE_DIR, "data")
OUT_DIR = os.path.join(BASE_DIR, "out")

@app.route("/", methods=["GET"])
def index():
    # Lista de invernaderos (TDA) + último resultado (si existe) para habilitar botones
    invs = sistema.invernaderos if sistema.invernaderos is not None else ListaSimple()
    ultimo = app.config.get("__ULTIMO_RESULTADO__")  # dict con inv, plan_nombre, resultado
    return render_template("index.html", invernaderos=invs, ultimo=ultimo)

@app.route("/descargar/salida")
def descargar_salida():
    # Sirve el out/salida.xml si existe; si no, mensaje y vuelve al inicio
    xml_path = os.path.join(OUT_DIR, "salida.xml")
    if not os.path.exists(xml_path):
        flash("Aún no hay salida.xml. Ejecute una simulación primero.")
        return redirect(url_for("index"))
    return send_from_directory(OUT_DIR, "salida.xml", as_attachment=True)


@app.route("/cargar", methods=["POST"])
def cargar():
    # Guardar archivo a ./data/entrada.xml (reemplaza)
    f = request.files.get("archivo")
    if not f:
        flash("No se seleccionó archivo")
        return redirect(url_for("index"))
    os.makedirs(DATA_DIR, exist_ok=True)
    ruta = os.path.join(DATA_DIR, "entrada.xml")
    f.save(ruta)

    # Parsear y cargar en el sistema
    ParserXML(sistema).cargar_desde_archivo(ruta)
    flash("Archivo cargado y configuración almacenada en memoria.")
    return redirect(url_for("index"))

@app.route("/simular", methods=["POST"])
def simular():
    inv_nombre = request.form.get("invernadero")
    plan_nombre = request.form.get("plan")

    if not inv_nombre or not plan_nombre:
        flash("Seleccione invernadero y plan.")
        return redirect(url_for("index"))

    inv = sistema.obtener_invernadero(inv_nombre)
    if inv is None:
        flash("Invernadero no encontrado.")
        return redirect(url_for("index"))

    # Validar pertenencia del plan al invernadero (UI ya filtra, pero reforzamos)
    pertenece = False
    for p in inv.planes:
        if p.nombre == plan_nombre:
            pertenece = True
            break
    if not pertenece:
        flash("El plan seleccionado no pertenece al invernadero elegido.")
        return redirect(url_for("index"))

    try:
        sim = Simulador(sistema)
        resultado = sim.simular_plan(inv_nombre, plan_nombre)
    except Exception as e:
        app.logger.exception("Error en simulación")
        flash(f"Error en simulación: {e}")
        return redirect(url_for("index"))

    # (tu mismo flujo para escribir salida.xml, reportes, etc.)
    from ..tda.Mapa import Mapa
    mp_plan = Mapa(); mp_plan.set(plan_nombre, resultado)
    mp_inv  = Mapa(); mp_inv.set(inv_nombre, mp_plan)

    os.makedirs(OUT_DIR, exist_ok=True)
    WriterXML(sistema).escribir_salida(os.path.join(OUT_DIR, "salida.xml"), mp_inv)
    ReporteHTML(OUT_DIR).generar_por_invernadero(inv, mp_plan)

    app.config["__ULTIMO_RESULTADO__"] = {"inv": inv, "plan_nombre": plan_nombre, "resultado": resultado}
    return render_template("resultado.html", inv=inv, plan_nombre=plan_nombre, resultado=resultado)



@app.route("/reporte/<inv_safe_name>")
def reporte(inv_safe_name):
    # Abrir archivo generado
    filename = "Reporte_{}.html".format(inv_safe_name)
    return send_from_directory(OUT_DIR, filename)

@app.route("/grafo-tda")
def grafo_tda():
    t = request.args.get("t", type=int, default=1)
    data = app.config.get("__ULTIMO_RESULTADO__")
    if not data:
        flash("Primero ejecute una simulación.")
        return redirect(url_for("index"))
    inv = data["inv"]
    resultado = data["resultado"]
    os.makedirs(OUT_DIR, exist_ok=True)
    svg_path = TDAGraphRenderer(OUT_DIR).render_estado(inv, resultado, t)
    return send_from_directory(OUT_DIR, os.path.basename(svg_path))

@app.route("/ayuda")
def ayuda():
    return render_template("ayuda.html")
